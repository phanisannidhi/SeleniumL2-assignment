import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.Test;







public class Demoshoptestcase {
	
	

	@Test
	public void scroll() {
		
		PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/Wipro.Demshop/config.properties");
		WebDriverManager.chromedriver().setup();
       
		// System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
      
        options.addArguments("--remote-allow-origins=*");
        
        WebDriver driver = new ChromeDriver(options);
        
        driver.get(config.getProperty("appUrl"));
  

         System.out.println("checking1");
         
         JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
       
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        
       String customer_service_heading= driver.findElement(By.xpath("//*[@class='column customer-service']/h3[contains(., 'Customer service')]")).getText();
        
       System.out.println(" header text=" + "" + customer_service_heading );
       
       driver.findElement(By.partialLinkText("Blog")).click();
       
        String Blog_current_pageURL = driver.getCurrentUrl();
  
         System.out.println("Blog current page url=  " + " " + Blog_current_pageURL);
        
     
         if(driver.getCurrentUrl().equals("https://demowebshop.tricentis.com/blog"))
     	{
     		System.out.println("Actual URL validated with Expected URL and it is PASS");
     	}
     		else{
     			System.out.println("you are not in blog page");
     		}

       
                  String Blog_archive = driver.findElement(By.xpath("//*[@class='title'][contains(., 'Blog archive')]")).getText();
        
                  System.out.println("Blog archieve text" + Blog_archive);
     	
         
         try {
             // Capture a screenshot
             File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

             // Specify the destination path for the screenshot
             String screenshotPath = "C:/Users/sphan/DemoshopAutomation/Wipro.Demshop/target/Screenshots/DemoshopblogPage.png";

             // Save the screenshot to the specified path
            FileUtils.copyFile(screenshotFile, new File(screenshotPath));

             
         } catch (Exception e) {
             e.printStackTrace(); 
         
         
         
         
         
 
	
      // Close the WebDriver instance
         driver.quit();
}	

}
}
