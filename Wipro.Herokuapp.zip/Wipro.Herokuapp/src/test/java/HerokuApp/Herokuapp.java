package HerokuApp;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Herokuapp {

	
	@Test
	
	public void hkapp() {
		
		PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/Wipro.Herokuapp/target/config.properties");
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
		      
	        options.addArguments("--remote-allow-origins=*");
	        
	        WebDriver driver = new ChromeDriver(options);
	        
	        driver.get(config.getProperty("appUrl"));
  
		
      //JS Alert button   	
        driver.findElement(By.xpath("//*[@id='content']/div//li[1]/button[contains(., 'Click for JS Alert')]")).click();
        
        //driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[1]/button")).click();          	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        Alert alert = driver.switchTo().alert();		
        String alertMessage= driver.switchTo().alert().getText();		
        System.out.println(alertMessage);	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        alert.accept();	
        
        String Result1 = driver.findElement(By.id("result")).getText();
        System.out.println("JS Alert button  - ok -  "+Result1);
        String Expected_result1 = "You successfully clicked an alert";
        if(Result1.equals(Expected_result1))
		{
			System.out.println("Result 1 is as expected");
		}else{
			System.out.println("Result 1 is not as expected");
		}
        //JS Confirm button  - ok     
        driver.findElement(By.xpath("//*[@id='content']/div//li[2]/button[contains(., 'Click for JS Confirm')]")).click();
        
        // driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[2]/button")).click();
        Alert alert1 = driver.switchTo().alert();		
        String alertMessage1= driver.switchTo().alert().getText();		
        System.out.println(alertMessage1);	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        alert.accept();	
        
        String Result2 = driver.findElement(By.id("result")).getText();
        System.out.println("JS confirm button  - ok -  "+Result2);
        String Expected_result2 = "You clicked: Ok";
        if(Result2.equals(Expected_result2))
		{
			System.out.println("Result 2 is as expected");
		}else{
			System.out.println("Result 2 is not as expected");
		}
      //JS Confirm button  - cancel    

        driver.findElement(By.xpath("//*[@id='content']/div//li[3]/button[contains(., 'Click for JS Prompt')]")).click();
        
        //driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[2]/button")).click();
        Alert alert3 = driver.switchTo().alert();		
        String alertMessage3= driver.switchTo().alert().getText();		
        System.out.println(alertMessage3);	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        alert.dismiss();
        
        String Result3 = driver.findElement(By.id("result")).getText();
        System.out.println("JS Confirm button  - cancel -  "+Result3);
        String Expected_result3 = "You clicked: Cancel";
        if(Result3.equals(Expected_result3))
		{
			System.out.println("Result 3 is as expected");
		}else{
			System.out.println("Result 3 is not as expected");
		}
        
        //JS Prompt button  - ok     
        driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[3]/button")).click();
        Alert alert4 = driver.switchTo().alert();		
        String alertMessage4= driver.switchTo().alert().getText();		
        System.out.println(alertMessage4);	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        alert.accept();	
        
        String Result4 = driver.findElement(By.id("result")).getText();
        System.out.println("JS Prompt button  - ok -  "+Result4);
        String Expected_result4 = "You entered:";
        if(Result4.equals(Expected_result4))
		{
			System.out.println("Result 4 is as expected");
		}else{
			System.out.println("Result 4 is not as expected");
		}
      //JS Prompt button  - cancel    
        driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[3]/button")).click();
        Alert alert5 = driver.switchTo().alert();		
        String alertMessage5= driver.switchTo().alert().getText();		
        System.out.println(alertMessage4);	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        alert.dismiss();
        
        String Result5 = driver.findElement(By.id("result")).getText();
        
        System.out.println("JS Prompt button  - cancel -  "+Result5);
        String Expected_result5 = "You entered: null";
        if(Result5.equals(Expected_result5))
        {
			System.out.println("Result 5 is as expected");
		}else{
			System.out.println("Result 5 is not as expected");
		}
		
        
        
        try {
            // Capture a screenshot
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Specify the destination path for the screenshot
            String screenshotPath = "C:/Users/sphan/DemoshopAutomation/Wipro.Herokuapp/target/Screenshots/Herokupage.png";

            // Save the screenshot to the specified path
           FileUtils.copyFile(screenshotFile, new File(screenshotPath));

            
        } catch (Exception e) {
            e.printStackTrace(); 
        

       
	}
        // Close the WebDriver instance
        driver.quit();
		
}
}

