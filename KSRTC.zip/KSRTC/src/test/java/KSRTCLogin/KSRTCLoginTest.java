package KSRTCLogin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KSRTCLoginTest {

    private WebDriver driver = null;
    PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/KSRTC/target/config.properties");

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password,String email) throws IOException {
        driver.get(config.getProperty("appUrl"));
        driver.manage().window().maximize();

        WebElement Signin = driver.findElement(By.xpath("//*[@class='ml-auto-left']/ul/li/a[1][contains(., 'Sign In')]"));
        Signin.click();

        // Locate username and password fields
        WebElement usernameField = driver.findElement(By.name("userName"));
        WebElement passwordField = driver.findElement(By.name("password"));
        WebElement termsCondition = driver.findElement(By.id("TermsConditions"));

        // Enter username and password
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", termsCondition);

        // Click on the login button
        WebElement loginButton = driver.findElement(By.name("submitBtn"));
        loginButton.click();
        
        
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        // Specify the destination path for the screenshot
        String screenshotPath = "C:/Users/sphan/DemoshopAutomation/KSRTC/target/Screenshots/lOGINPAGEERROR.png";

        // Save the screenshot to the specified path
       FileUtils.copyFile(screenshotFile, new File(screenshotPath));

        
        
        
        WebElement forgotpasswordlink = driver.findElement(By.xpath("//a[text()='Forgot Password']"));
        forgotpasswordlink.click();

        WebElement forgotPasswordTextBox = driver.findElement(By.xpath("//label[text()='Email/Login ID']"));

        JavascriptExecutor js1 = (JavascriptExecutor) driver;
        js1.executeScript("arguments[0].click();",forgotPasswordTextBox);
        
        WebElement emailTextBox = driver.findElement(By.id("userName"));
        emailTextBox.sendKeys(email);

        WebElement fgtpwdsubmt = driver.findElement(By.id("submitBtn"));
        fgtpwdsubmt.click();
        

        File screenshotFile2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        // Specify the destination path for the screenshot
        String screenshotPath2 = "C:/Users/sphan/DemoshopAutomation/KSRTC/target/Screenshots/FORGOTPAGEERROR.png";

        // Save the screenshot to the specified path
       FileUtils.copyFile(screenshotFile2, new File(screenshotPath2));
        
    }

    @DataProvider(name = "loginData")
    public String[][] getData() throws IOException {
        String[][] data = null;

        try {
            String excelFilePath = "C:/Users/sphan/DemoshopAutomation/KSRTC/TestData.xlsx";
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0);

            int lastrownumber = sheet.getLastRowNum();
            System.out.println(" last row number" + "" + lastrownumber);
            data = new String[lastrownumber +1][3]; // Initialize the data array

            for (int i = 0; i <= lastrownumber; i++) {
                Row row = sheet.getRow(i);

                int cellnumber = row.getLastCellNum();
                

                for (int j = 0; j < cellnumber; j++) {
                    Cell cell = row.getCell(j);
                    String value = cell.getStringCellValue();

                    data[i][j] = value;
                   
                }
            }

            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
}
