package Newtours;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;


import io.github.bonigarcia.wdm.WebDriverManager;

public class NewtoursRegistrations {


	@Test
	
	public void newtoursregistrations_negativetest() {
		
		PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/Wipro.NewtoursRegistration/target/config.properties");
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
		      
	        options.addArguments("--remote-allow-origins=*");
	        
	        WebDriver driver = new ChromeDriver(options);
	        
	        driver.get(config.getProperty("appUrl"));
  
	        
	        
	       
	        // Fill in the registration form with incorrect data
	        WebElement firstName = driver.findElement(By.name("firstName"));
	        firstName.sendKeys("John");

	        WebElement lastName = driver.findElement(By.name("lastName"));
	        lastName.sendKeys("Doe");

	        WebElement phone = driver.findElement(By.name("phone"));
	        phone.sendKeys("123");  // Invalid phone number

	        WebElement email = driver.findElement(By.id("userName"));
	        email.sendKeys("johndoe@example.com");

	        WebElement address = driver.findElement(By.name("address1"));
	        address.sendKeys("123 Main Street");

	        WebElement city = driver.findElement(By.name("city"));
	        city.sendKeys("Anytown");

	        WebElement state = driver.findElement(By.name("state"));
	        state.sendKeys("CA");

	        WebElement postalCode = driver.findElement(By.name("postalCode"));
	        postalCode.sendKeys("12345");

	        WebElement country = driver.findElement(By.name("country"));
	        country.sendKeys("UNITED STATES");

	        WebElement username = driver.findElement(By.id("email"));
	        username.sendKeys("johndoe");  // Duplicate username

	        WebElement password = driver.findElement(By.name("password"));
	        password.sendKeys("password123");

	        WebElement confirmPassword = driver.findElement(By.name("confirmPassword"));
	        confirmPassword.sendKeys("password456");  // Passwords don't match

			
	        
	        WebElement iframe = driver.findElement(By.id("gdpr-consent-notice"));
	        driver.switchTo().frame(iframe);
	        WebElement GDPNOTICE = driver.findElement(By.xpath("//span[contains(text(),'Accept All')]"));
	        GDPNOTICE.click();
	        
	        driver.switchTo().defaultContent();;
	        
			  
	        WebElement registerButton = driver.findElement(By.name("submit"));
	        registerButton.click();
	        

	        // Verify that the registration failed and an error message is displayed
	        WebElement registrationvalidationMessage = driver.findElement(By.xpath("//span[contains(text(),'PAssword and con.password does not match')]"));
	        Assert.assertTrue(registrationvalidationMessage.isDisplayed(), "Registration validation message is displayed.");
	        
	        
	        //Closing the browser
	        driver.quit();
	        
	    }

}
