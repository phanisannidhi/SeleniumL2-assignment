package Newtours;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Newtourspostivietest {
	
	
@Test
	
	public void newtoursregistrations_positivetest() {
		
		PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/Wipro.NewtoursRegistration/target/config.properties");
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
		      
	        options.addArguments("--remote-allow-origins=*");
	        
	        WebDriver driver = new ChromeDriver(options);
	        
	        driver.get(config.getProperty("appUrl"));
	      
	        
	        
	        
	        WebElement firstName = driver.findElement(By.name("firstName"));
	        firstName.sendKeys("John");
	        
	        WebElement lastName = driver.findElement(By.name("lastName"));
	        lastName.sendKeys("Doe");
	        
	        WebElement phone = driver.findElement(By.name("phone"));
	        phone.sendKeys("1234567890");
	        
	        WebElement email = driver.findElement(By.id("userName"));
	        email.sendKeys("johndoe@example.com");
	        
	        WebElement address = driver.findElement(By.name("address1"));
	        address.sendKeys("123 Main Street");
	        
	        WebElement city = driver.findElement(By.name("city"));
	        city.sendKeys("Anytown");
	        
	        WebElement state = driver.findElement(By.name("state"));
	        state.sendKeys("CA");
	        
	        WebElement postalCode = driver.findElement(By.name("postalCode"));
	        postalCode.sendKeys("12345");
	        
	        WebElement country = driver.findElement(By.name("country"));
	        country.sendKeys("UNITED STATES");
	        
	        WebElement username = driver.findElement(By.id("email"));
	        username.sendKeys("johndoe");
	        
	        WebElement password = driver.findElement(By.name("password"));
	        password.sendKeys("password123");
	        
	        WebElement confirmPassword = driver.findElement(By.name("confirmPassword"));
	        confirmPassword.sendKeys("password123");
	        
	        
			/*
			 * WebElement iframe = driver.findElement(By.id("gdpr-consent-notice"));
			 * driver.switchTo().frame(iframe); // Find and interact with elements within
			 * the iframe driver.switchTo().defaultContent();
			 */
	        WebElement iframe = driver.findElement(By.id("gdpr-consent-notice"));
	        driver.switchTo().frame(iframe);
	        WebElement GDPNOTICE = driver.findElement(By.xpath("//span[contains(text(),'Accept All')]"));
	        GDPNOTICE.click();
	        
	        driver.switchTo().defaultContent();;
	        
			  
	        WebElement registerButton = driver.findElement(By.name("submit"));
	        registerButton.click();
	        WebElement registrationsuccessMessage = driver.findElement(By.xpath("//table[@width='492']//font[contains(text(),'Thank you for registering.')]"));
	        Assert.assertTrue(registrationsuccessMessage.isDisplayed(), "Registration success message is displayed.");
	        
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        
	        //Closing the browser
	        driver.quit();
	        
	        
	        
	       
	        
	        
	     
	        
	        
	        
}
	        

}

