package Demoguru99;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Demoguru99stocks {

	

public class Herokuapp {

	
	@Test
	public void scroll() {
		
		PropertiesUtil config = new PropertiesUtil("C:/Users/sphan/DemoshopAutomation/Wipro.Demoguru99/target/config.properties");
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
	      
        options.addArguments("--remote-allow-origins=*");
        
        WebDriver driver = new ChromeDriver(options);
        
        driver.get(config.getProperty("appUrl"));
        
        
        try {
            // Capture a screenshot
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Specify the destination path for the screenshot
            String screenshotPath = "C:/Users/sphan/DemoshopAutomation/Wipro.Demoguru99/target/Screenshots/Demoguru99Part1.png";

            // Save the screenshot to the specified path
           FileUtils.copyFile(screenshotFile, new File(screenshotPath));

            
        } catch (Exception e) {
            e.printStackTrace(); 
        
        
        }
        
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        
        try {
            // Capture a screenshot
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Specify the destination path for the screenshot
            String screenshotPath = "C:/Users/sphan/DemoshopAutomation/Wipro.Demoguru99/target/Screenshots/Demogurupart2.png";

            // Save the screenshot to the specified path
           FileUtils.copyFile(screenshotFile, new File(screenshotPath));

            
        } catch (Exception e) {
            e.printStackTrace(); 
        
        
        }
       
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        
        
     // Locate the table element using its XPath or other locating strategy
        WebElement table = driver.findElement(By.xpath("//table[@class='dataTable']"));
        
        // Find all rows in the table
        java.util.List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        // Find all columns in the first row (header row)
        java.util.List<WebElement> columns = rows.get(0).findElements(By.tagName("th"));
        
        // Print the number of rows and columns
        int rowCount = rows.size();
        int columnCount = columns.size();
        System.out.println("Number of rows: " + rowCount);
        System.out.println("Number of columns: " + columnCount);
        
        
        double maxPrice = 0.0;
        String companyName = "";
        

        // Loop through the rows, starting from the second row (skip the header row)
        for (int i = 1; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            java.util.List<WebElement> columns1 = row.findElements(By.tagName("td"));

            // Assuming that the current price is in the 3rd column (adjust if necessary)
            String currentPriceText = columns1.get(3).getText();
            double currentPrice = Double.parseDouble(currentPriceText.replaceAll("[^\\d.]", ""));

            if (currentPrice > maxPrice) {
                maxPrice = currentPrice;

                // Assuming the company name is in the 1st column (adjust if necessary)
                companyName = columns1.get(0).getText();
            }
        }

        System.out.println("Company with maximum current price: " + companyName);
        System.out.println("Maximum current price: $" + maxPrice);
        
       
        
        // Close the WebDriver
     driver.quit();
	
         
	
}
     }
          }
